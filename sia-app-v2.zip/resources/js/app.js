import './bootstrap';

import '@fortawesome/fontawesome-free/css/all.css'
import '@fortawesome/fontawesome-free/js/all.js'

import Alpine from 'alpinejs';

window.Alpine = Alpine;

Alpine.start();

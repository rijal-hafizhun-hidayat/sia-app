<div class="flex flex-row">
    <div class="py-2"><p>Nama Guru:</p></div>
    <div class="rounded bg-slate-300 ml-2 basis-1/3 py-2"><p class="capitalize ml-3">{{ $guru->nama }}</div>
</div>
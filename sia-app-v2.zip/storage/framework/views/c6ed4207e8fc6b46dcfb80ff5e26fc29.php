<div class="flex flex-row">
    <div class="py-2"><p>Nama User:</p></div>
    <div class="rounded bg-slate-300 ml-2 basis-1/3 py-2"><p class="capitalize ml-3"><?php echo e($user->nama); ?></div>
</div><?php /**PATH E:\sia-app\resources\views/users/partials/detail-users.blade.php ENDPATH**/ ?>
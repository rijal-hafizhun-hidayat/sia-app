<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        table, th, td {
          border:1px solid black;
          border-collapse: collapse;
        }
    </style>
</head>
<body>
    <?php $__currentLoopData = $mapels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mapel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p>Kelas: <?php echo e($mapel->kelas->nama); ?></p>
        <p>Tahun Ajaran: <?php echo e($mapel->kelas->tahun_ajaran); ?></p>
        <p>Mata Pelajaran: <?php echo e($mapel->nama); ?></p>
        <p>Hari: <?php echo e($mapel->hari); ?> (<?php echo e($mapel->schedule_start_at); ?> - <?php echo e($mapel->schedule_end_at); ?>)</p>

        <table style="width:100%">
            <tr>
                <th>Nama Siswa</th>
                <th>Nilai UTS</th> 
                <th>Nilai UAS</th>
            </tr>
            <?php $__currentLoopData = $mapel->nilai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nilai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($nilai->user->nama); ?></td>
                    <td><?php echo e($nilai->nilai_uts); ?></td>
                    <td><?php echo e($nilai->nilai_uas); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html><?php /**PATH E:\sia-app\resources\views/nilai/report-nilai-pdf.blade.php ENDPATH**/ ?>
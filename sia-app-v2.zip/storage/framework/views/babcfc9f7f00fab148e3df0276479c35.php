<table class="w-full whitespace-nowrap">
    <thead>
        <tr class="text-left font-bold">
            <th class="pb-4 pt-6 px-6">Nama Mata Pelajaran Yang Diampu</th>
            <th class="pb-4 pt-6 px-6">Kelas</th>
            <th class="pb-4 pt-6 px-6">Hari</th>
            <th class="pb-4 pt-6 px-6">Waktu Mulai</th>
            <th class="pb-4 pt-6 px-6">Waktu Selesai</th>
            <th class="pb-4 pt-6 px-6">Action</th>
        </tr>
    </thead>
    
    <tbody>
        <?php $__currentLoopData = $user->mapel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mapel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="hover:bg-gray-100 uppercase">
            <td class="border-t items-center px-6 py-4">
                <?php echo e($mapel->nama); ?>

            </td>
            <td class="border-t items-center px-6 py-4">
                <?php echo e($mapel->kelas->nama); ?>

            </td>
            <td class="border-t items-center px-6 py-4">
                <?php echo e($mapel->hari); ?>

            </td>
            <td class="border-t items-center px-6 py-4">
                <?php echo e(timeFormat($mapel->schedule_start_at)); ?>

            </td>
            <td class="border-t items-center px-6 py-4">
                <?php echo e(timeFormat($mapel->schedule_end_at)); ?>

            </td>
            <td class="border-t items-center px-6 py-4">
                <div class="flex flex-row space-x-4">
                    <form action="<?php echo e(route('mapel.destroy', ['id' => $mapel->id])); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.danger-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('danger-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Hapus <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                    </form>
                </div>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH E:\sia-app\resources\views/users/partials/detail-users-guru-mapels.blade.php ENDPATH**/ ?>
<select <?php echo $attributes->merge(['class' => 'border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm']); ?>>
    <?php echo e($slot); ?>

</select><?php /**PATH E:\sia-app\resources\views/components/select-input.blade.php ENDPATH**/ ?>
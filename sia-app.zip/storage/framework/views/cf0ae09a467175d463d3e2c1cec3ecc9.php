<div class="bg-red-500 dark:bg-gray-800 overflow-hidden shadow-md sm:rounded-lg">
    <div class="p-6 text-white dark:text-gray-100">
        <?php echo e($slot); ?>

    </div>
</div><?php /**PATH E:\sia-app\resources\views/components/danger-delete-notif.blade.php ENDPATH**/ ?>
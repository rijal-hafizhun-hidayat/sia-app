<div class="bg-green-500 overflow-hidden shadow-md sm:rounded-lg">
    <div class="p-6 text-white">
       {{ $slot }}
    </div>
</div>